
import React, { useState } from 'react';
import { JouninFrogIcon } from './icons/PetIcons';

interface LoginScreenProps {
  onLogin: (username: string) => void;
  t: (key: string) => string;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, t }) => {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onLogin(username.trim());
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-primary p-4 text-text-main animate-fade-in">
      <div className="w-48 h-48 mb-8">
        <JouninFrogIcon />
      </div>
      <h1 className="text-4xl font-bold text-highlight mb-2">Anime Den</h1>
      <p className="text-text-secondary mb-8">{t('login.welcome')}</p>
      <form onSubmit={handleSubmit} className="w-full max-w-sm flex flex-col items-center">
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value.replace(/\s/g, ''))}
          placeholder={t('login.placeholder')}
          className="w-full bg-secondary p-3 rounded-md border-2 border-accent focus:outline-none focus:ring-2 focus:ring-highlight text-center"
          autoFocus
        />
        <button
          type="submit"
          disabled={!username.trim()}
          className="mt-4 w-full bg-highlight px-6 py-3 rounded-md text-white font-bold text-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {t('login.button')}
        </button>
      </form>
    </div>
  );
};

export default LoginScreen;
